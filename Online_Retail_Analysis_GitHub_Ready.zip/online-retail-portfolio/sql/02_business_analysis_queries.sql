-- MySQL 8.0+ business analysis questions
USE online_retail;

-- 1. Overall KPIs
SELECT COUNT(*) AS sales_lines, SUM(Quantity) AS units_sold,
       ROUND(SUM(Revenue),2) AS gross_revenue, COUNT(DISTINCT Invoice) AS invoices,
       COUNT(DISTINCT CustomerID) AS identified_customers
FROM retail_sales;

-- 2. Monthly revenue trend
SELECT DATE_FORMAT(InvoiceDate,'%Y-%m') AS year_month,
       ROUND(SUM(Revenue),2) AS revenue, SUM(Quantity) AS units,
       COUNT(DISTINCT Invoice) AS invoices
FROM retail_sales GROUP BY year_month ORDER BY year_month;

-- 3. Top 10 countries by revenue
SELECT Country, ROUND(SUM(Revenue),2) AS revenue,
       COUNT(DISTINCT Invoice) AS invoices, COUNT(DISTINCT CustomerID) AS customers
FROM retail_sales GROUP BY Country ORDER BY revenue DESC LIMIT 10;

-- 4. Top 10 products by revenue
SELECT StockCode, Description, SUM(Quantity) AS units_sold,
       ROUND(SUM(Revenue),2) AS revenue
FROM retail_sales GROUP BY StockCode, Description ORDER BY revenue DESC LIMIT 10;

-- 5. Average order value (AOV)
WITH invoice_totals AS (SELECT Invoice, SUM(Revenue) AS invoice_revenue FROM retail_sales GROUP BY Invoice)
SELECT ROUND(AVG(invoice_revenue),2) AS average_order_value FROM invoice_totals;

-- 6. Repeat customer analysis
WITH customer_orders AS (
 SELECT CustomerID, COUNT(DISTINCT Invoice) AS order_count, SUM(Revenue) AS lifetime_revenue
 FROM retail_sales WHERE CustomerID IS NOT NULL GROUP BY CustomerID
)
SELECT COUNT(*) AS identified_customers,
       SUM(order_count > 1) AS repeat_customers,
       ROUND(100*SUM(order_count > 1)/COUNT(*),2) AS repeat_customer_pct,
       ROUND(AVG(lifetime_revenue),2) AS avg_customer_revenue
FROM customer_orders;

-- 7. Month-over-month revenue change
WITH monthly AS (
 SELECT DATE_FORMAT(InvoiceDate,'%Y-%m-01') AS month_start, SUM(Revenue) AS revenue
 FROM retail_sales GROUP BY DATE_FORMAT(InvoiceDate,'%Y-%m-01')
), compared AS (
 SELECT month_start, revenue, LAG(revenue) OVER (ORDER BY month_start) AS previous_month_revenue FROM monthly
)
SELECT month_start, ROUND(revenue,2) AS revenue, ROUND(previous_month_revenue,2) AS previous_month_revenue,
       ROUND(100*(revenue-previous_month_revenue)/NULLIF(previous_month_revenue,0),2) AS mom_growth_pct
FROM compared ORDER BY month_start;

-- 8. Product contribution within each country
WITH country_product AS (
 SELECT Country, StockCode, Description, SUM(Revenue) AS revenue
 FROM retail_sales GROUP BY Country, StockCode, Description
), ranked AS (
 SELECT *, ROW_NUMBER() OVER (PARTITION BY Country ORDER BY revenue DESC) AS product_rank,
        SUM(revenue) OVER (PARTITION BY Country) AS country_revenue
 FROM country_product
)
SELECT Country, StockCode, Description, ROUND(revenue,2) AS revenue,
       ROUND(100*revenue/NULLIF(country_revenue,0),2) AS country_revenue_share_pct
FROM ranked WHERE product_rank <= 5 ORDER BY Country, product_rank;
