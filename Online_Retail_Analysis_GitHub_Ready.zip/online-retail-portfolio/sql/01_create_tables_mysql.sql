-- MySQL 8.0+ | Online Retail portfolio project
CREATE DATABASE IF NOT EXISTS online_retail;
USE online_retail;

-- Export each worksheet in the source workbook as CSV, then append both CSVs
-- into this staging table. Column order matches the original 8 source columns.
CREATE TABLE IF NOT EXISTS retail_staging (
  Invoice VARCHAR(20),
  StockCode VARCHAR(30),
  Description VARCHAR(255),
  Quantity INT,
  InvoiceDate DATETIME,
  Price DECIMAL(12,4),
  CustomerID INT NULL,
  Country VARCHAR(100)
);

-- Load the two exported CSV files using MySQL Workbench's Table Data Import
-- Wizard, mapping the eight source columns to retail_staging.

CREATE TABLE IF NOT EXISTS retail_sales (
  SaleLineID BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  Invoice VARCHAR(20) NOT NULL,
  StockCode VARCHAR(30) NOT NULL,
  Description VARCHAR(255),
  Quantity INT NOT NULL,
  InvoiceDate DATETIME NOT NULL,
  Price DECIMAL(12,4) NOT NULL,
  CustomerID INT NULL,
  Country VARCHAR(100),
  Revenue DECIMAL(18,4) GENERATED ALWAYS AS (Quantity * Price) STORED,
  InvoiceYear SMALLINT,
  InvoiceMonth TINYINT,
  INDEX idx_date (InvoiceDate),
  INDEX idx_country (Country),
  INDEX idx_customer (CustomerID),
  INDEX idx_product (StockCode),
  INDEX idx_invoice (Invoice)
);

-- Load completed sale lines only. The source marks cancellation invoices
-- with a leading C; positive quantity and positive price are also required.
INSERT INTO retail_sales
(Invoice, StockCode, Description, Quantity, InvoiceDate, Price, CustomerID, Country, InvoiceYear, InvoiceMonth)
SELECT TRIM(Invoice), TRIM(StockCode), Description, Quantity, InvoiceDate, Price,
       CustomerID, Country, YEAR(InvoiceDate), MONTH(InvoiceDate)
FROM retail_staging
WHERE InvoiceDate IS NOT NULL
  AND Invoice NOT LIKE 'C%'
  AND Quantity > 0
  AND Price > 0;

-- Check load results before analysis.
SELECT COUNT(*) AS loaded_sale_lines,
       COUNT(DISTINCT Invoice) AS distinct_invoices,
       COUNT(DISTINCT CustomerID) AS identified_customers,
       ROUND(SUM(Revenue),2) AS gross_revenue
FROM retail_sales;
