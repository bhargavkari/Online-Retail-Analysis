# Online Retail Business Analysis & Customer Purchase Behaviour

## Project overview
An end-to-end Data Analyst portfolio project using the Online Retail II transaction dataset (December 2009–December 2011). The workflow combines Python-based data preparation and exploratory analysis with MySQL business queries, an Excel summary workbook, and a Power BI dashboard build guide. The original regression notebook is retained as an additional modelling extension.

## Business questions
- How does revenue change month over month?
- Which countries and products contribute most to revenue?
- How many invoices and units are generated?
- What is the average order value?
- What share of identified customers place repeat orders?

## Repository structure
```text
├── Online_Retail_Data_Analysis.ipynb   # Existing Python cleaning, EDA and modelling workflow
├── data/raw/README.md                # Instructions for obtaining the source workbook
├── sql/01_create_tables_mysql.sql      # MySQL staging and fact table setup
├── sql/02_business_analysis_queries.sql# Business analysis queries (CTEs/window functions)
├── excel/Online_Retail_Excel_Analysis.xlsx # Verified aggregate analysis workbook
├── powerbi/Measures.dax                # DAX measures
├── powerbi/Dashboard_Build_Guide.md    # Dashboard layout and validation steps
├── docs/Online_Retail_Analysis_Report.docx # Existing detailed report
└── requirements.txt
```

## Tools
Python, Pandas, NumPy, Matplotlib, Seaborn, Scikit-learn, Statsmodels, Jupyter Notebook, MySQL 8+, Excel, Power BI.

## Business metric definitions
- **Revenue:** Quantity × Price at line-item level. The analysis uses completed-sale rows with positive quantity and price. This is gross line revenue, not profit; shipping, tax and other adjustments are not included unless already represented in Price.
- **Average Order Value:** Total revenue divided by distinct invoices.
- **Identified Customers:** Distinct non-null Customer IDs. Customer metrics exclude anonymous transactions.
- **Repeat Customer:** An identified customer with more than one distinct invoice in the analysed period.

## How to run
1. Create a Python environment and install dependencies: `pip install -r requirements.txt`.
2. Download the Online Retail II source workbook as described in `data/raw/README.md`, place it at `data/raw/online_retail_II.xlsx`, then open the notebook from the repository root.
3. For SQL, export each source workbook worksheet as CSV, append both into `retail_staging` using MySQL Workbench (the staging schema follows the original eight source columns), then run the SQL scripts in order. The SQL load step identifies cancellation invoices by the `C` prefix and retains only positive-quantity, positive-price lines. Compare the final row count and revenue with the Python/Excel summary before publishing results.
4. Open the Excel workbook for pre-aggregated summaries.
5. Follow the Power BI guide and validate report totals against SQL/Excel.

## Data quality and analytical considerations
The source workbook is intentionally excluded from this repository because it is approximately 43.5 MB; see `data/raw/README.md` for setup. The source contains missing Customer IDs, cancellations/returns, duplicates and unusual transaction records. Keep raw data unchanged; document every exclusion and distinguish sales from returns/cancellations. The included Excel summary was generated from the supplied analysis-ready CSV, filtered to `Transaction_Type = 'Completed Sale'`, `Quantity > 0`, and `Price > 0`. The SQL workflow uses the raw workbook and applies the cancellation-prefix plus positive-quantity/positive-price rules; validate that both workflows produce matching totals before reporting them as identical.

The existing notebook includes a purchase-quantity regression extension. Treat it as exploratory rather than a production forecasting model: evaluate chronological validation, feature availability at prediction time, and leakage risks before presenting predictive performance as deployment-ready.

## Resume-ready project entry
**Online Retail Business Analysis & Customer Purchase Behaviour** | Python, SQL (MySQL), Excel, Power BI
- Prepared and analysed a large historical retail transaction dataset, documenting data-quality rules for missing customer identifiers, duplicates, cancellations and invalid transaction values.
- Built SQL business analysis covering revenue trends, top products/countries, average order value and repeat-customer behaviour using aggregations, CTEs and window functions.
- Created an Excel analysis workbook with KPI, monthly, country and product summaries; defined a Power BI dashboard layout and reusable DAX measures.
- Retained an exploratory Python regression workflow as an extension, with model limitations and validation considerations documented.

## Important honesty note
The Excel summary and SQL/DAX assets are prepared. A `.pbix` dashboard file is not included; build it in Power BI Desktop using the supplied guide and measures, then add the finished `.pbix` to this repository. Do not claim a completed Power BI dashboard until you have built and validated it.
