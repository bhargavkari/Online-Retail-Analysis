# Power BI dashboard build guide

## Import
1. Import the `retail_sales` table from MySQL (or import the validated CSV export).
2. Create a Date table and a date-only column in the sales table; relate Date[Date] to retail_sales[SalesDate].
3. Add measures from `Measures.dax`.

## Suggested one-page report
- KPI cards: Total Revenue, Units Sold, Sales Invoices, Average Order Value, Identified Customers.
- Line chart: monthly revenue trend.
- Bar chart: Top 10 products by revenue.
- Bar/map: revenue by country.
- Matrix: Country × Product with revenue and units.
- Slicers: Date, Country, Product, Source Year.

## Design and validation
- Use a consistent currency format and thousands separators.
- Sort month labels by a real date field, not alphabetically.
- Cross-check Power BI totals against the Excel KPI Summary and SQL overall KPI query.
- Clearly label revenue as line-item gross sales (Quantity × Price), not net profit.
