# Source dataset

The original `online_retail_II.xlsx` workbook is intentionally not included in this GitHub repository because it is approximately 43.5 MB.

To run `Online_Retail_Data_Analysis.ipynb`:

1. Obtain the **Online Retail II** dataset from the UCI Machine Learning Repository.
2. Keep the downloaded workbook named `online_retail_II.xlsx`.
3. Place it in this folder: `data/raw/online_retail_II.xlsx`.
4. Run the notebook from the repository root.

The workbook is expected to contain the worksheets `Year 2009-2010` and `Year 2010-2011`.

The source file is kept separate from the repository to make cloning and browser uploads lighter. Do not replace the original source data with the aggregated Excel workbook; they serve different purposes.
